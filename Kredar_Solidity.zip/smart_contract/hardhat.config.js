

// This is a sample Hardhat task. 
// https://eth-ropsten.alchemyapi.io/v2/Bn5tm9fX90ET1hKwb76lKJB0rzU3JBi2

require("@nomiclabs/hardhat-waffle");


module.exports = {
  solidity: '0.8.0',
  networks: {
    ropsten: {
      url: "https://eth-ropsten.alchemyapi.io/v2/Bn5tm9fX90ET1hKwb76lKJB0rzU3JBi2",
      accounts: ["63b598044c3cce8d656a3db5cd73c89a74ab7c64beb17eb1687aebbefc5cac8a"]
    }
  }
}
