import abi from './Transactions.json';

export const contractABI = abi.abi;

export const contractAddress = "0x808454034a94F95bEB5660240983F802c93351F3";